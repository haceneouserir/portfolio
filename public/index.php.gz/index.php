<?php
// Bootstrap the application
require __DIR__ . '/../bootstrap/session.php';
require __DIR__ . '/../bootstrap/config.php';
// Render the main view
require __DIR__ . '/../resources/view/index.php';
?>